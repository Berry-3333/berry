#!/usr/bin/env python3
"""Zharief Domain Atlas: deterministic unique pronounceable synthetic domains, offline."""
import argparse, csv, gzip, json, math, os, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CONSONANTS = 'bcdfghjklmnprstvwxz'  # 19 consonants
VOWELS = 'aeiou'
SYLLABLES = tuple(c+v for c in CONSONANTS for v in VOWELS)
BASE = len(SYLLABLES)
SPACE = BASE ** 4


def load_tlds(path):
    out=[]
    seen=set()
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        s=line.strip().lower().lstrip('.')
        if not s or s.startswith('#'): continue
        if not all(x.isascii() and (x.isalnum() or x=='-') for x in s):
            raise ValueError('Invalid ASCII/Punycode TLD: '+s)
        if s not in seen: seen.add(s);out.append(s)
    if not out: raise ValueError('Empty TLD list')
    return out


def name_at(index):
    # 8-character CV-CV-CV-CV. Bijective across 95^4 names.
    # Fixed affine permutation with coprime multiplier for non-sequential names.
    x=(index*7919+104729)%SPACE
    parts=[]
    for _ in range(4):
        x,r=divmod(x,BASE)
        parts.append(SYLLABLES[r])
    return ''.join(parts)


def write_state(path, state):
    temp=path.with_suffix('.tmp')
    temp.write_text(json.dumps(state,indent=2),encoding='utf-8')
    os.replace(temp,path)


def main():
    ap=argparse.ArgumentParser(description='Offline pronounceable synthetic domain CSV.GZ generator')
    ap.add_argument('--rows',type=int,default=1_000_000_000)
    ap.add_argument('--output',default='domains.csv.gz')
    ap.add_argument('--tlds',default=str(HERE/'tlds.txt'))
    ap.add_argument('--chunk',type=int,default=100_000,help='Checkpoint frequency')
    ap.add_argument('--resume',action='store_true')
    ap.add_argument('--preview',type=int,default=0,help='Show N rows, without writing output')
    args=ap.parse_args()
    if args.rows<1 or args.chunk<1: ap.error('rows and chunk must be positive')
    tlds=load_tlds(Path(args.tlds))
    maximum=SPACE*len(tlds)
    if args.rows>maximum: ap.error(f'Maximum unique combinations: {maximum:,}')
    if args.preview:
        print('id,domain,tld,name')
        for i in range(min(args.preview,args.rows)):
            tld=tlds[i%len(tlds)]; name=name_at(i//len(tlds))
            print(f'{i+1},{name}.{tld},{tld},{name}')
        return
    output=Path(args.output).resolve()
    output.parent.mkdir(parents=True,exist_ok=True)
    statefile=Path(str(output)+'.checkpoint.json')
    state={'next_row':0,'bytes':0,'rows':args.rows,'tlds':len(tlds),'tld_file':str(Path(args.tlds).resolve())}
    if args.resume:
        if not statefile.exists(): ap.error('No checkpoint to resume')
        state=json.loads(statefile.read_text(encoding='utf-8'))
        if (state['rows']!=args.rows or state['tlds']!=len(tlds) or state['tld_file']!=str(Path(args.tlds).resolve())):
            ap.error('Checkpoint settings differ from current options')
        if not output.exists(): ap.error('Output file missing')
        if output.stat().st_size<state['bytes']: ap.error('Output shorter than checkpoint')
        with output.open('r+b') as f: f.truncate(state['bytes'])
    else:
        if output.exists() or statefile.exists(): ap.error('Output/checkpoint already exists; use --resume or a different --output')
        output.touch()
        write_state(statefile,state)
    start=time.monotonic()
    i=state['next_row']
    while i<args.rows:
        stop=min(i+args.chunk,args.rows)
        with output.open('ab') as raw:
            with gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=5,mtime=0) as zipped:
                import io
                writer=csv.writer(io.TextIOWrapper(zipped,encoding='utf-8',newline='',write_through=True))
                if i==0: writer.writerow(['id','domain','tld','name'])
                for row in range(i,stop):
                    tld=tlds[row%len(tlds)]
                    name=name_at(row//len(tlds))
                    writer.writerow([row+1,name+'.'+tld,tld,name])
            raw.flush()
            os.fsync(raw.fileno())
        i=stop
        state['next_row']=i
        state['bytes']=output.stat().st_size
        write_state(statefile,state)
        elapsed=max(time.monotonic()-start,0.001)
        print(f'{i:,}/{args.rows:,} rows ({i/args.rows:.2%}); {state["bytes"]/(1024**2):.1f} MiB; {elapsed:.1f}s',flush=True)
    print('COMPLETE:',output)

if __name__=='__main__': main()
