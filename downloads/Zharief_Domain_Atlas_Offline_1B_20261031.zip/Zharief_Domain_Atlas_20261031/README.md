# Zharief Domain Atlas — Offline Python Generator

Produces up to **1,000,000,000 unique synthetic domain strings** in a single `CSV.GZ` file, using only the Python standard library. No internet or API is needed to generate data.

## Start (Windows PowerShell)

```powershell
cd Zharief_Domain_Atlas_20261031
python generate_domains.py --preview 10
python generate_domains.py --rows 100000 --output test.csv.gz
python generate_domains.py --rows 1000000000 --output domains_1b.csv.gz
```

To resume an interrupted run, use the **same** options and append `--resume`:

```powershell
python generate_domains.py --rows 1000000000 --output domains_1b.csv.gz --resume
```

The checkpoint is saved next to the output. A crash may lose at most one chunk; resume safely truncates uncheckpointed gzip bytes. Output is one `.csv.gz` file containing concatenated valid gzip members. Python's `gzip.open` reads them normally. Do not delete the checkpoint before the job completes.

## Output columns

`id,domain,tld,name` — unique domain strings, not verified registrations or available domains.

## Naming algorithm

Four consonant-vowel syllables form eight-character names (e.g. `bavoniku`). A bijective affine mapping prevents duplicates for a given TLD. The generator cycles across the bundled TLD list; every (name, TLD) pair is unique up to the configured capacity. Names are pronounceable-ish, **not linguistically screened**, and may accidentally coincide with existing brands or offensive words. It does not check domain availability.

## TLD list and provenance — IMPORTANT

`https://data.iana.org/TLD/tlds-alpha-by-domain.txt` is the authoritative official IANA list. The official list was checked as of **2026-10-30** (version `2026103000`, 1436 entries), but this environment could not download that file directly into the ZIP. Therefore the bundled `tlds.txt` is an **offline root-entry snapshot extracted from the OpenJDK Public Suffix List**, which is *not guaranteed to be an exact current IANA list*. Some entries may differ or be stale. This limitation is deliberate and documented rather than mislabeling the bundled data as a verified IANA export.

To use the **exact official IANA list** offline, download the official file once, replace `tlds.txt` with it, and then run the generator with no network connection. The parser accepts IANA comment lines and uppercase Punycode labels. Some TLDs are restricted or not available for public registration.

## Performance

Memory is approximately constant in row count. 1 billion rows can require tens of gigabytes of disk space and many hours/days depending on hardware. Try `--rows 100000` first. Python 3.9+ recommended.
