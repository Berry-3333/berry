ZHARIEF — 2 QUADRILLION CONCEPTUAL JOB COMBINATIONS
===================================================

START HERE
1. Install Python 3.9 or newer from https://www.python.org/downloads/
2. Extract this ZIP to a folder on your computer.
3. Open the folder in VS Code or a terminal.
4. Run: python generate_zharief.py --rows 1000 --output jobs.txt
5. Open jobs.txt in a text editor (UTF-8, tab-separated columns).

INCLUDED FILES
- generate_zharief.py : offline Python generator
- README.txt : quick-start instructions (this file)
- COMPLETE_SETUP_GUIDE_ENGLISH.txt : detailed English tutorial
- sample_100_rows.txt : 100 generated sample rows

GENERATE MORE DATA
100,000 rows: python generate_zharief.py --rows 100000 --output jobs_100k.txt
1 million rows: python generate_zharief.py --rows 1000000 --output jobs_1m.txt
Next million: python generate_zharief.py --start 1000000 --rows 1000000 --output jobs_part2.txt
Compressed CSV alternative: python generate_zharief.py --rows 1000000 --output jobs.csv.gz

IMPORTANT
2,000,000,000,000,000 is the mathematical number of combinations
addressable by this generator. The ZIP does NOT contain that many records.
Generated rows are synthetic conceptual variants, not verified unique jobs.
Some labels are placeholder slots, not actual countries or job specialties.
Cloudflare Pages can host these files for download, but cannot run Python
within a static website. Run the generator locally or on a Python server.

NUMBERED JOB NAMES (NEW)
Each row now has a job_code column and a scenario number in its idea title.
Example: RICE-FARMER-007 and Rice farmer 007.
The global ID is unique for each combination. The short job_code is NOT globally unique: it may repeat for different settings, scales, technologies or countries.
The maximum theoretical ID remains 2,000,000,000,000,000.
