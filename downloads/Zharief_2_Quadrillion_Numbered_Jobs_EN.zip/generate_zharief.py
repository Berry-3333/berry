#!/usr/bin/env python3
"""Zharief conceptual job-idea generator. No claim of verified unique professions."""
import argparse, csv
from pathlib import Path

# 200 x 10,000 x 100 x 100 x 100 x 10 x 10 x 10 = 2,000,000,000,000,000
# Country slots are geographic scenario labels, not an authoritative list of sovereign states.
COUNTRIES = ["Indonesia","Japan","United States","Germany","India","Brazil","France","South Korea","Australia","Canada"]
JOBS = ["Rice farmer","Anime designer","Software developer","Marine researcher","Solar technician",
        "Nurse","Architect","Teacher","Automotive engineer","Fashion designer"]
TECH = ["AI","robotics","drones","sensors","3D printing","cloud","VR","satellite","automation","manual"]
ACT = ["designing","building","monitoring","teaching","repairing","researching","testing","planning","operating","improving"]
TARGETS = ["households","schools","small businesses","industry","researchers","farmers","children","cities","clinics","communities"]

RADICES = (200, 10000, 100, 100, 100, 10, 10, 10)
TOTAL = 1
for r in RADICES: TOTAL *= r
assert TOTAL == 2_000_000_000_000_000

def decode(n):
    vals=[]
    for base in reversed(RADICES):
        n, rem=divmod(n,base)
        vals.append(rem)
    return list(reversed(vals))

def record(n):
    country, job, tech, act, target, setting, scale, scenario=decode(n)
    # Labels after the seed list are explicitly synthetic scenario slots.
    c=COUNTRIES[country] if country<len(COUNTRIES) else f"Geographic scenario {country+1:03d}"
    j=JOBS[job%len(JOBS)] if job<len(JOBS) else f"{JOBS[job%len(JOBS)]} specialization {job//len(JOBS)+1}"
    t=TECH[tech%len(TECH)] + (f" variant {tech//len(TECH)+1}" if tech>=len(TECH) else "")
    a=ACT[act%len(ACT)] + (f" variant {act//len(ACT)+1}" if act>=len(ACT) else "")
    g=TARGETS[target%len(TARGETS)] + (f" variant {target//len(TARGETS)+1}" if target>=len(TARGETS) else "")
    job_code=f"{j.upper().replace(chr(32), chr(45))}-{scenario+1:03d}"
    title=f"{j} {scenario+1:03d} — {a} with {t} for {g} ({c})"
    return [n+1,job_code,c,j,t,a,g,setting+1,scale+1,scenario+1,title,"Synthetic conceptual combination; not verified as a distinct job"]

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--start",type=int,default=0,help="Zero-based combination offset")
    p.add_argument("--rows",type=int,default=1000,help="Rows to actually write")
    p.add_argument("--output",default="sample.txt",help="Output .txt (tab-separated), .csv, or .csv.gz")
    args=p.parse_args()
    if args.start<0 or args.rows<0 or args.start+args.rows>TOTAL: p.error("Range outside 2 quadrillion combinations")
    dest=Path(args.output)
    dest.parent.mkdir(parents=True,exist_ok=True)
    import gzip
    opener=gzip.open if dest.suffix==".gz" else open
    with opener(dest,"wt",encoding="utf-8",newline="") as f:
        w=csv.writer(f, delimiter="\t" if dest.suffix==".txt" else ",")
        w.writerow(["id","job_code","geography","job_seed","technology","activity","target","setting_slot","scale_slot","scenario_slot","idea","disclaimer"])
        for n in range(args.start,args.start+args.rows):
            w.writerow(record(n))
    print(f"Wrote {args.rows:,} rows to {dest}. Theoretical address space: {TOTAL:,} combinations.")
if __name__=="__main__": main()
