#!/usr/bin/env python3
"""Zharief offline synthetic data generator. Python 3.9+, standard library only."""
import argparse,csv,gzip,random,secrets,string,pathlib
MODE = 'world-languages'
FIRST=['Alexander','Daniel','Olivia','Amelia','Noah','Maya','Sofia','Liam','Aisha','Haruto','Yuna','Arjun','Nadia','Elena','Mateo','Grace']
LAST=['Morgan','Rivera','Chen','Tanaka','Khan','Patel','Smith','Johnson','Kim','Hassan','Garcia','Wilson','Brown','Sato','Park','Lee']
JOBS=[('Technology','Software Engineer'),('Technology','Cloud Engineer'),('Science','Research Assistant'),('Education','Language Tutor'),('Healthcare','Medical Data Analyst'),('Arts','Animation Designer'),('Agriculture','Precision Farming Technician'),('Business','E-commerce Specialist'),('Energy','Solar Systems Technician'),('Transport','Logistics Coordinator')]
# Small illustrative local vocabulary, NOT a complete 195-country dictionary.
LANG=[('Indonesia','Indonesian','rumah','house'),('Japan','Japanese','未来','future'),('France','French','bonjour','hello'),('Germany','German','Freundschaft','friendship'),('South Korea','Korean','학교','school'),('China','Mandarin Chinese','世界','world'),('Russia','Russian','спасибо','thank you'),('Saudi Arabia','Arabic','مرحبا','hello'),('India','Hindi','नमस्ते','hello'),('Spain','Spanish','esperanza','hope'),('Brazil','Portuguese','amizade','friendship'),('Italy','Italian','lavoro','work'),('Turkey','Turkish','merhaba','hello'),('Thailand','Thai','สวัสดี','hello'),('Vietnam','Vietnamese','xin chào','hello')]
def fields():
 return {'job-ideas':['ID','Sector','Job_Idea','Description'],'person-names':['ID','Full_Name','First_Name','Last_Name'],'email-addresses':['ID','Email','Username'],'passwords':['ID','Password'],'world-languages':['ID','Country','Language','Word','English_Meaning'],'random-numbers':['ID','Random_Number']}[MODE]
def make(i,rng):
 if MODE=='job-ideas':
  sector,job=rng.choice(JOBS);method=rng.choice(['AI-assisted','manual','cloud-based','community-led']);return [i,sector,job,f'{job} using {method} methods (synthetic concept)']
 if MODE=='person-names':
  a=rng.choice(FIRST);b=rng.choice(LAST);return [i,a+' '+b,a,b]
 if MODE=='email-addresses':
  a=rng.choice(FIRST).lower();b=rng.choice(LAST).lower();u=f'{a}.{b}{i}';return [i,u+'@example.com',u]
 if MODE=='passwords':
  chars=string.ascii_letters+string.digits+'!@#$%';return [i,''.join(secrets.choice(chars) for _ in range(18))]
 if MODE=='world-languages':return [i,*rng.choice(LANG)]
 if MODE=='random-numbers':return [i,secrets.randbelow(10**12)]
def main():
 p=argparse.ArgumentParser(description='Generate synthetic records offline to streaming CSV.GZ')
 p.add_argument('--rows',type=int,default=1000,help='number of records')
 p.add_argument('--output',default='output.csv.gz',help='output .csv.gz filename')
 p.add_argument('--seed',type=int,default=42,help='reproducible seed for non-security data')
 a=p.parse_args()
 if a.rows<1: p.error('--rows must be positive')
 out=pathlib.Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
 rng=random.Random(a.seed)
 with gzip.open(out,'wt',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(fields())
  for i in range(1,a.rows+1):w.writerow(make(i,rng))
 print(f'Wrote {a.rows:,} synthetic records to {out}')
if __name__=='__main__':main()
