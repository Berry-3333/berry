# ZHARIEF — JOB IDEAS

FULL OFFLINE SETUP & USAGE GUIDE (ENGLISH)

## 1. What is included
- generate.py — standalone Python 3 generator; no API and no external packages.
- sample_20.csv.gz — 20 example rows in compressed CSV format.
- README_FULL_SETUP_ENGLISH.md — this complete guide.

## 2. System requirements
Windows 10/11, macOS, or Linux. Install Python 3.9 or newer. Python is required only for this downloadable offline tool; the Zharief website itself is static HTML/JS.

## 3. Install Python on Windows
1. Download Python from https://www.python.org/downloads/ (internet needed only to install Python if you do not have it).
2. Run the installer and enable 'Add python.exe to PATH'.
3. Open PowerShell and run: `python --version`
4. If the command is unavailable, try `py --version`.

## 4. Extract the ZIP
1. Right-click the downloaded ZIP and choose Extract All.
2. Open the single extracted folder `Zharief_01_job-ideas`.
3. Open PowerShell in that folder (in File Explorer, type `powershell` in the address bar).

## 5. Generate your first dataset
Run: `python generate.py --rows 1000 --output my_data.csv.gz`
Or: `py generate.py --rows 1000 --output my_data.csv.gz`

## 6. Generate larger files
Run: `python generate.py --rows 1000000 --output one_million.csv.gz`
The script streams rows to GZIP-compressed CSV, without holding the entire dataset in RAM. Available disk space and execution time still matter.

## 7. View your data
Open `sample_20.csv.gz` with an archive utility, or decompress `.csv.gz` before opening the CSV in a spreadsheet. Large CSVs are best inspected with Python, VS Code extensions, or database tools rather than opening all rows in a spreadsheet.

## 8. Output fields
ID, Sector, Job_Idea, Description

## 9. Limitations and safety
- Records are fictional, automatically generated, and not verified against real-world data.
- Repetition is possible for names, jobs, and language words; record IDs are unique within each export.
- Email addresses use reserved `example.com`, not real inboxes.
- Generated passwords are examples for test datasets, not credentials to publish or reuse for real accounts.
- World Languages uses a small curated local vocabulary across 15 language examples; it does NOT translate all languages of 195 countries.
- Job ideas are synthetic concepts, not employment vacancies.
- Numeric output is random test data, not measured statistics.
- The random seed controls non-security examples only; password and number generators use operating-system secure randomness.

## 10. Customization
Open `generate.py` in VS Code. Expand FIRST, LAST, JOBS, or LANG lists to improve vocabulary coverage and variety. Keep UTF-8 encoding for multilingual data.

## 11. Troubleshooting
- 'python is not recognized': install Python or try the `py` command.
- Permission denied: save to a writable folder, e.g. Desktop.
- Output too large: lower `--rows`, ensure disk space.
- Accented characters look wrong: import CSV as UTF-8.

## 12. Cloudflare Pages note
These Python scripts run locally, not inside a static Cloudflare Pages website. The site can host the downloadable ZIP files unchanged.
