WORLD KNOWLEDGE & OPPORTUNITY TREE — ENGLISH EDITION

PURPOSE
Generate conceptual ideas across occupations, fields, businesses, activities and hobbies, innovations and future scenarios. All generated fields and instructions are in English. Ideas are inspired by 195 reference countries and intended for worldwide application, not just Indonesia. Future settings such as Mars are explicitly speculative.

IMPORTANT
This package contains a working generator, a complete 19,500-row ZIP index, a country reference list, and a small sample. It DOES NOT contain 975 billion pre-generated records. No API, live research, official occupational taxonomy, or country-specific verification is used. Repeated or implausible ideas may occur. Numeric scenario suffixes do not make an idea substantively unique.

QUICK START (VS CODE / POWERSHELL)
1. Extract this ZIP and open the folder in VS Code.
2. Open Terminal > New Terminal.
3. Test: python generate_world_ideas.py --country JP --rows 10000
4. Generate 1 million: python generate_world_ideas.py --country JP --rows 1000000
5. Generate a full 50-million-record ZIP: python generate_world_ideas.py --country JP --part 1 --rows 50000000 --per-txt 1000000
6. Global ZIP #18015: python generate_world_ideas.py --global-part 18015 --rows 10000
7. Inspect global record #900750000000 instantly: python generate_world_ideas.py --lookup 900750000000
8. Speculative Mars sample: python generate_world_ideas.py --country JP --location Mars --rows 10000
9. Apply to a particular location: python generate_world_ideas.py --country US --application "Nairobi, Kenya" --rows 10000
10. List countries: python generate_world_ideas.py --list-countries

INDEXING
195 countries x 5 billion = 975 billion target entries.
100 ZIPs per country x 50 million = 5 billion.
19,500 ZIPs total.
Global ZIP number = ceil(global ID / 50,000,000).
For a global ZIP index, country index = floor((ZIP number - 1) / 100) + 1.
Country-local part = ((ZIP number - 1) modulo 100) + 1.

PROGRESS & SAFETY
Progress prints after each TXT file completes. Default: 1 million records per TXT.
A .tmp file is an in-progress archive. Do not open it while writing.
Do not run two processes generating the same ZIP. Do not delete existing .tmp files before checking them.
Huge runs can require substantial time and storage; run small samples first.
