#!/usr/bin/env python3
"""English conceptual world opportunity generator. Offline; no APIs or validated job data."""
import argparse,csv,time,zipfile,os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
COUNTRIES=list(csv.DictReader((ROOT/'195_countries.csv').open(encoding='utf-8-sig',newline='')))
FIELDS=[('Education','Language teaching','Language tutor','Language school'),('Software','Programming','Software developer','Application studio'),('Science','Research','Research scientist','Research services'),('Entertainment','Video games','Game player and designer','Game studio'),('Creative arts','Animation','Character designer','Animation studio'),('Retail','E-commerce','Online seller','Online marketplace'),('Fashion','Clothing','Fashion designer','Clothing store'),('Food','Regional cuisine','Food product developer','Restaurant'),('Healthcare','Medical research','Biomedical researcher','Biotech venture'),('Engineering','Robotics','Robotics engineer','Robot integrator'),('Agriculture','Precision farming','Agricultural technician','Smart farm'),('Space','Space infrastructure','Space systems designer','Space logistics venture'),('Energy','Renewable energy','Energy technician','Renewable power service'),('Culture','Heritage preservation','Cultural researcher','Cultural tourism venture'),('Logistics','Delivery networks','Logistics planner','Delivery business'),('Sports','Competitive gaming','Esports coach','Esports academy'),('Finance','Digital payments','Payments analyst','Payment services'),('Environment','Recycling','Circular economy designer','Recycling business'),('Construction','Habitat design','Habitat engineer','Habitat design studio'),('Media','Content production','Content producer','Media studio')]
TYPES=['Field idea','Occupation idea','Business idea','Activity or hobby','Innovation idea','Future scenario']
ACTIVITIES=['learning','designing','teaching','playing','testing','building','repairing','trading','researching','operating','creating','coaching']
SPECIALTIES=['beginner','advanced','children','adults','accessibility','small enterprise','industrial','multilingual','local culture','remote service','premium','low cost','open source','data driven','sustainable','robot assisted','AI assisted','community based','research oriented','custom products']
TECH=['manual','software','AI','robotics','sensors','cloud','3D printing','simulation','renewable energy','mixed reality']
SCALES=['individual','home','micro','small','medium','large','industrial','interplanetary']
HORIZONS=['Current possibility','Near future','Research concept','Speculative future']
FOCUS={'US':'AI, aerospace and science','JP':'anime, games and robotics','RU':'geology, minerals and energy','CN':'regional cuisines, manufacturing and industrial robots','IN':'software, languages and pharmaceuticals','KR':'electronics, entertainment and semiconductors','ID':'local languages, biodiversity and culture','FR':'fashion, cuisine and art','DE':'engineering and automotive systems','BR':'agriculture and biodiversity'}
HEADER='Global_ID\tReference_Country\tApplication_Scope\tLocation\tIdea_Type\tField\tSubfield\tOccupation\tActivity\tSpecialization\tTechnology\tBusiness_Scale\tTime_Horizon\tCountry_Inspiration\tIdea_Title\tParent_Path\tEvidence_Status\n'
def record(global_id, country, location, application):
    within=(global_id-1)%5_000_000_000+1
    x=within-1
    def pick(seq):
        nonlocal x
        val=seq[x%len(seq)];x//=len(seq);return val
    typ=pick(TYPES); field,sub,job,business=pick(FIELDS);activity=pick(ACTIVITIES);specialty=pick(SPECIALTIES);tech=pick(TECH);scale=pick(SCALES);horizon=pick(HORIZONS)
    scenario=x
    focus=FOCUS.get(country['Code'],'cross-cultural and multidisciplinary inspiration')
    base={'Field idea':sub,'Occupation idea':job,'Business idea':business,'Activity or hobby':activity+' in '+sub,'Innovation idea':'Innovation in '+sub,'Future scenario':'Future concept for '+sub}[typ]
    title=f'{base} — {specialty}, {tech}, {scale} scale, scenario {scenario:07d}'
    if location.lower()!='earth':horizon='Speculative future';title+=f' on {location}'
    path='/'.join([location.lower().replace(' ','-'),field.lower().replace(' ','-'),sub.lower().replace(' ','-'),typ.lower().replace(' ','-')])
    cols=[str(global_id),country['Country'],application,location,typ,field,sub,job,activity,specialty,tech,scale,horizon,focus,title,path,'Generated conceptual combination; not independently verified']
    return '\t'.join(cols)+'\n'
def create(country_index,part,rows,per_txt,output,location,application):
    if not 1<=country_index<=195 or not 1<=part<=100 or not 1<=rows<=50_000_000 or per_txt<1:raise ValueError('Invalid country/part/rows/per-txt')
    country=COUNTRIES[country_index-1];global_part=(country_index-1)*100+part
    first=(global_part-1)*50_000_000+1
    output.mkdir(parents=True,exist_ok=True)
    dest=output/f'World_Ideas_Part_{global_part:05d}_{country["Code"]}.zip';tmp=dest.with_suffix('.tmp')
    if dest.exists():
        with zipfile.ZipFile(dest) as z:
            if z.testzip() is None:print('Already complete:',dest);return
        raise RuntimeError('Existing ZIP is damaged; inspect it before retrying: '+str(dest))
    if tmp.exists():raise RuntimeError('Temporary file exists; do not overwrite until checked: '+str(tmp))
    start=time.monotonic()
    with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True) as z:
        for offset in range(0,rows,per_txt):
            count=min(per_txt,rows-offset)
            with z.open(f'Ideas_{global_part:05d}_{offset//per_txt+1:03d}.txt','w',force_zip64=True) as out:
                out.write(HEADER.encode())
                for pos in range(offset,offset+count,5000):
                    end=min(pos+5000,offset+count)
                    out.write(''.join(record(first+j,country,location,application) for j in range(pos,end)).encode())
            done=offset+count
            print(f'ZIP {global_part:05d}: {done:,}/{rows:,} ({done/rows:.2%}) elapsed {time.monotonic()-start:.0f}s',flush=True)
        z.writestr('README.txt',f'English conceptual ideas. Reference country: {country["Country"]}. Application: {application}. Location: {location}. Global IDs: {first:,}–{first+rows-1:,}. Not a verified database of unique occupations or businesses.\n')
    os.replace(tmp,dest)
    print('Complete:',dest)
def main():
    p=argparse.ArgumentParser(description='Offline generator: 975 billion potential entries (195 countries x 5 billion); world application')
    p.add_argument('--country',default='JP',help='Reference country code, e.g. JP, US, CN, ID')
    p.add_argument('--part',type=int,default=1,help='Part 1..100 per country')
    p.add_argument('--global-part',type=int,help='Global ZIP index 1..19500 (overrides --country and --part)')
    p.add_argument('--rows',type=int,default=10000,help='Number of records to write, up to 50000000')
    p.add_argument('--per-txt',type=int,default=1000000)
    p.add_argument('--application',default='Worldwide',help='Worldwide or specific country/region')
    p.add_argument('--location',default='Earth',help='Earth, Mars, Moon, orbital habitat, etc.')
    p.add_argument('--output',default='output')
    p.add_argument('--list-countries',action='store_true')
    p.add_argument('--lookup',type=int,help='Print one global ID instantly; no ZIP generated')
    a=p.parse_args()
    if a.list_countries:
        for i,c in enumerate(COUNTRIES,1):print(i,c['Code'],c['Country'])
        return
    if a.lookup is not None:
        if not 1<=a.lookup<=975_000_000_000:p.error('lookup must be 1..975000000000')
        idx=(a.lookup-1)//5_000_000_000
        print(HEADER,end='');print(record(a.lookup,COUNTRIES[idx],a.location,a.application),end='');return
    if a.global_part is not None:
        if not 1<=a.global_part<=19500:p.error('global-part must be 1..19500')
        idx=(a.global_part-1)//100+1;part=(a.global_part-1)%100+1
    else:
        idx=next((i for i,c in enumerate(COUNTRIES,1) if c['Code']==a.country.upper()),None)
        if idx is None:p.error('Unknown country code')
        part=a.part
    create(idx,part,a.rows,a.per_txt,Path(a.output),a.location,a.application)
if __name__=='__main__':main()
